package com.github.revival.common.enums;

public enum EnumPigmenSpeaks
{
    SelfKill,
    LifeFor,
    AnuSommon;
}
