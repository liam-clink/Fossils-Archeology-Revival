package com.github.revival.common.api;

public interface INamedBlock
{
    String getBlockName();
}
