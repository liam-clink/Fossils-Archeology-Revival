package com.github.revival.common.enums;

public enum EnumEra
{
    Now,
    StoneAge,
    Cretaceous,
    Jurassic,
    Triassic;
}
