package com.github.revival.common.entity.mobs;

public class FossilAnimation
{

}
