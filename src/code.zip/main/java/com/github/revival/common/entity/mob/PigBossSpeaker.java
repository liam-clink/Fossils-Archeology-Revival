package com.github.revival.common.entity.mob;

import com.github.revival.common.enums.EnumPigBossSpeaks;

public class PigBossSpeaker
{
    public void SendSpeech(EnumPigBossSpeaks var1)
    {
    }
}
