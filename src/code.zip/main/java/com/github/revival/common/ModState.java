package com.github.revival.common;

public enum ModState
{
    DEV,
    BETA,
    RELEASE
}
