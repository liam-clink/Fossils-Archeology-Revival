package com.github.revival.common.container;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;

public class ContainerNotebook extends Container
{
    public boolean canInteractWith(EntityPlayer var1)
    {
        return true;
    }
}
