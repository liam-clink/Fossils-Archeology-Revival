package com.github.revival.common.enums;

public enum EnumMobType {
 DINOSAUR, MAMMAL, VANILLA, BIRD, CHICKEN, TERRORBIRD, FISH, OTHER;
}
