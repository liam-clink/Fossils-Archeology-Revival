package com.github.revival.common.enums;

public enum EnumTimePeriod {
PALEOZOIC, MESOZOIC, CENOZOIC, CURRENT;
}
