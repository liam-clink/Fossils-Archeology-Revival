package com.github.revival.common.enums;

public enum EnumSituation
{
    Hungry,
    Starve,
    StarveUntame,
    LearningChest,
    Betrayed,
    NoSpace,
    StarveEsc,
    SJLBite,
    ChewTime,
    Full,
    Nervous,
    GemErrorYoung,
    GemErrorHealth;
}