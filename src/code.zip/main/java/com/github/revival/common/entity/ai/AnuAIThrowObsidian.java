package com.github.revival.common.entity.ai;

public class AnuAIThrowObsidian
{

}
